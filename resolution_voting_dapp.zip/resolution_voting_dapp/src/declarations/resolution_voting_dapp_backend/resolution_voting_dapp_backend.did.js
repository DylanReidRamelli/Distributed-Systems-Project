export const idlFactory = ({ IDL }) => {
  const ResolutionId = IDL.Nat;
  const Resolution = IDL.Record({
    'id' : ResolutionId,
    'title' : IDL.Text,
    'creator' : IDL.Principal,
    'against_weight' : IDL.Nat,
    'description' : IDL.Text,
    'created_at' : IDL.Nat64,
    'abstain_weight' : IDL.Nat,
    'for_weight' : IDL.Nat,
  });
  const VoteChoice = IDL.Variant({
    'For' : IDL.Null,
    'Abstain' : IDL.Null,
    'Against' : IDL.Null,
  });
  return IDL.Service({
    'createResolution' : IDL.Func(
        [IDL.Text, IDL.Text],
        [IDL.Variant({ 'ok' : ResolutionId, 'err' : IDL.Text })],
        [],
      ),
    'faucet' : IDL.Func([], [IDL.Nat], []),
    'getMyBalance' : IDL.Func([], [IDL.Nat], []),
    'getResolution' : IDL.Func(
        [ResolutionId],
        [IDL.Opt(Resolution)],
        ['query'],
      ),
    'listResolutions' : IDL.Func([], [IDL.Vec(Resolution)], ['query']),
    'voteResolution' : IDL.Func(
        [ResolutionId, VoteChoice, IDL.Nat],
        [IDL.Variant({ 'ok' : Resolution, 'err' : IDL.Text })],
        [],
      ),
  });
};
export const init = ({ IDL }) => { return []; };
