import type { Principal } from '@dfinity/principal';
import type { ActorMethod } from '@dfinity/agent';
import type { IDL } from '@dfinity/candid';

export interface Resolution {
  'id' : ResolutionId,
  'title' : string,
  'creator' : Principal,
  'against_weight' : bigint,
  'description' : string,
  'created_at' : bigint,
  'abstain_weight' : bigint,
  'for_weight' : bigint,
}
export type ResolutionId = bigint;
export type VoteChoice = { 'For' : null } |
  { 'Abstain' : null } |
  { 'Against' : null };
export interface _SERVICE {
  /**
   * / Create a new resolution.
   */
  'createResolution' : ActorMethod<
    [string, string],
    { 'ok' : ResolutionId } |
      { 'err' : string }
  >,
  /**
   * / Simple faucet: give the caller 100 tokens if they have 0.
   */
  'faucet' : ActorMethod<[], bigint>,
  /**
   * / Get the caller's token balance.
   */
  'getMyBalance' : ActorMethod<[], bigint>,
  /**
   * / Get a single resolution by id.
   */
  'getResolution' : ActorMethod<[ResolutionId], [] | [Resolution]>,
  /**
   * / List all resolutions (visible to everyone).
   */
  'listResolutions' : ActorMethod<[], Array<Resolution>>,
  /**
   * / Vote on a resolution with a token amount.
   */
  'voteResolution' : ActorMethod<
    [ResolutionId, VoteChoice, bigint],
    { 'ok' : Resolution } |
      { 'err' : string }
  >,
}
export declare const idlFactory: IDL.InterfaceFactory;
export declare const init: (args: { IDL: typeof IDL }) => IDL.Type[];
